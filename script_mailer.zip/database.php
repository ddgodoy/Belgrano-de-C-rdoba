<?php

//test2
class database {

    private $show_errors = TRUE;
    private $default_conn = array('type' => 'mysql', 'host' => 'localhost', 'db_name' => 'club_belgrano', 'db_user' => 'root', 'db_pass' => 'pk1321');

    function __construct() {
        
    }

    public function get_conn($params = NULL) {
        if ($params == null) {
            $params = $this->default_conn;
        }

        $db = null;
        try {
            $db = new PDO($params['type'] . ':host=' . $params['host'] . ';dbname=' . $params['db_name'], $params['db_user'], $params['db_pass']);
        } catch (PDOException $e) {
            if ($this->show_errors) {
                echo 'Connection failed: ' . $e->getMessage();
            }
        }
        return $db;
    }

    public function set_show_errors(bool $status) {
        $this->show_errors = $status;
    }

    public function execute_stmt(PDO $db_handler, $query, $params = array()) {
        $stmt = $db_handler->prepare($query);
        $stmt->execute($params);

        $error = $stmt->errorInfo();
        if (intval($error[0])) {
            if ($this->show_errors) {
                echo '<pre>';
                //var_dump($stmt);
                echo '</pre>';
                echo '<pre>';
                //print_r($error);
                echo '</pre>';
                echo 'Query:' . $query;
                echo 'Params:';
                echo '<pre>';
                //print_r($params);
                echo '</pre>';
                die(pg_last_error());
            }
            return FALSE;
        } else {
            return $stmt;
        }
    }

    public function fetch_all_objects($stmt) {
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    /**
     * Inserta los datos de un arreglo asociativo en la tabla especificada
     * @param PDO $conn connection handler
     * @param string $table_name nombre de la tabla donde insertar
     * @param array $data array asociativo con datos a insertar
     * @return PDO
     */
    public function insert_array($conn, $table_name, $data) {

        $fields = implode(',', array_keys($data));
        $values = array_values($data);

        $total_values = count($values);
        $values_string = '';
        for ($i = 0; $i < $total_values; $i++) {
            $values_string.= '?,';
        }
        $values_string = substr_replace($values_string, "", -1);

        $query = 'INSERT INTO ' . $table_name . ' (' . $fields . ')' . ' VALUES (' . $values_string . ')';

        return $this->execute_stmt($conn, $query, $values);
    }

}
