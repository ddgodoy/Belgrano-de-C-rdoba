<?php

set_time_limit(0);
ini_set('display_errors', 'on');
include('database.php');
include('class.phpmailer.php');
include('class.smtp.php');

$id_poll = 1;
$id_poll_token = md5($id_poll);
$url = 'http://localhost/belgrano/web/app_dev.php/vote/show/';

$subject = 'Encuesta Socios';
$from_name = 'Club Atlético Belgrano';
$from_email = 'belgranoencuesta@icox.mobi';

$db = new database();
$conn = $db->get_conn();
$query = 'SELECT * FROM User WHERE id NOT IN (SELECT id_user FROM Vote WHERE id_poll = ?)';
$query_test = 'SELECT * FROM User WHERE email = ?';

$result_test = $db->execute_stmt($conn, $query_test, array('esteban.negri@gmail.com'));

//$result = $db->execute_stmt($conn, $query, array($id_poll));




$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host = "smtp.icox.mobi";
$mail->SMTPDebug = 2;
$mail->SMTPAuth = true;
$mail->Port = 587;
$mail->Username = "belgranoencuesta@icox.mobi";
$mail->Password = "iDua83~1";
$mail->Subject = $subject;
$mail->setFrom($from_email, $from_name);
$mail->isHTML(true);

$sent = 0;

while ($user = $result_test->fetch(PDO::FETCH_OBJ)) {
    
    $sent += 1;
    
    $id_user_token = md5($user->id);

    $token = $id_user_token . ':' . $id_poll_token;
    $link_url = $url . $token;
    
    $body = 'Aún no has completado la encuesta. Por favor haz click en el siguiente enlace para completarla: <br/><br/>'.$link_url;
    
    $mail->MsgHTML($body);
    $mail->AddAddress($user->email, $user->name.' '.$user->last_name);
    $mail->send();
    
    if ( ($sent % 1000) === 0) {
        'Enviados al momento: '.$sent.'. Pausando unos segundos para intentar evitar posibles bloqueos de servidores de correo...';
        sleep(15);
        echo 'Resumiendo...<br/><br/>';
        
        
    }
        
    
}

